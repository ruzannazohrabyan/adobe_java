package com.company.week12.classwork.crud.repository;

import com.company.week12.classwork.crud.model.Book;

public interface BookRepository {
    void create(Book book);
}
